from keep_alive import keep_alive

keep_alive()  # Web sunucusunu başlat

import discord
from discord.ext import commands
from discord.ui import View
import json
import os
from datetime import datetime
import pytz

TOKEN = os.getenv("TOKEN")
GUILD_ID = 986305394341187594  # int olarak yaz
LOG_CHANNEL_ID = 1375633599893868659  # içtima raporu atılacak kanal id'si

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

VERI_DOSYASI = "ictima_veri.json"

# Mesai saatleri aralıkları (string olarak)
MESAİ_ARALIKLARI = [
    "14:15-14:30", "05:30-15:00", "15:00-15:30", "15:30-16:00", "16:00-16:30",
    "16:30-17:00", "17:00-17:30", "17:30-18:00", "18:00-18:30", "18:30-19:00",
    "19:00-19:30", "19:30-20:00", "20:30-21:00", "21:00-21:30", "21:30-22:00",
    "22:00-22:30", "22:30-23:00", "23:00-23:30", "23:30-00:00"
]


def araligi_parse_et(aralik_str):
    baslangic_str, bitis_str = aralik_str.split("-")
    baslangic = datetime.strptime(baslangic_str.strip(), "%H:%M").time()
    bitis = datetime.strptime(bitis_str.strip(), "%H:%M").time()
    return baslangic, bitis


def simdiki_aralik():
    tz = pytz.timezone("Europe/Istanbul")  # İstanbul saat dilimi
    simdi = datetime.now(tz).time()
    for aralik_str in MESAİ_ARALIKLARI:
        bas, bit = araligi_parse_et(aralik_str)
        if bas > bit:  # Gece yarısını geçen aralıklar
            if simdi >= bas or simdi < bit:
                return aralik_str
        else:
            if bas <= simdi < bit:
                return aralik_str
    return None


def veri_yukle():
    if os.path.exists(VERI_DOSYASI):
        with open(VERI_DOSYASI, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}
    else:
        return {}


def veri_kaydet(veri):
    with open(VERI_DOSYASI, "w", encoding="utf-8") as f:
        json.dump(veri, f, indent=4, ensure_ascii=False)


# İçtima katılım buton view
class IctimaView(View):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="İçtimaya Katıl",
                       style=discord.ButtonStyle.success,
                       custom_id="katil")
    async def katil(self, interaction: discord.Interaction,
                    button: discord.ui.Button):
        now = datetime.now()
        tarih_str = now.strftime("%Y-%m-%d")
        aralik = simdiki_aralik()

        if aralik is None:
            await interaction.response.send_message(
                "❌ Şu anda mesai saatleri dışında olduğunuz için içtimaya katılamazsınız.",
                ephemeral=True)
            return

        veri = veri_yukle()
        user_id = str(interaction.user.id)
        display_name = interaction.user.display_name

        if tarih_str not in veri:
            veri[tarih_str] = {}

        if aralik not in veri[tarih_str]:
            veri[tarih_str][aralik] = {}

        if user_id in veri[tarih_str][aralik]:
            await interaction.response.send_message(
                f"❌ Bu saat aralığında zaten içtimaya katıldınız: {aralik}",
                ephemeral=True)
            return

        veri[tarih_str][aralik][user_id] = {
            "ad": display_name,
            "katilim_zamani": now.strftime("%H:%M:%S")
        }

        veri_kaydet(veri)

        await interaction.response.send_message(
            f"✅ {display_name}, {aralik} aralığında içtimaya katıldınız!",
            ephemeral=True)


@bot.command()
@commands.has_role("Astsubay Personel")  # veya istediğin rol
async def ictima(ctx):
    aralik = simdiki_aralik()
    if aralik is None:
        await ctx.send(
            "❌ Şu anda mesai saatleri dışında olduğunuz için içtima başlatamazsınız.",
            ephemeral=True)
        return
    view = IctimaView()
    await ctx.send("📢 İçtima başlamıştır. Katılmak için butona basınız.",
                   view=view)


@bot.command()
@commands.has_role("Astsubay Personel")  # komutu sadece komutan kullanabilir
async def ictima_bitir(ctx):
    veri = veri_yukle()
    tarih_str = datetime.now().strftime("%Y-%m-%d")

    if tarih_str not in veri or not veri[tarih_str]:
        await ctx.send("❌ Bugün için kayıtlı içtima bulunmamaktadır.")
        return

    kanal = bot.get_channel(LOG_CHANNEL_ID)
    if kanal is None:
        await ctx.send(
            "❌ Log kanalı bulunamadı, lütfen LOG_CHANNEL_ID'yi kontrol edin.")
        return

    embed = discord.Embed(title=f"📊 {tarih_str} Tarihli İçtima Raporu 📊",
                          color=discord.Color.blue(),
                          timestamp=datetime.utcnow())
    embed.set_footer(text="İçtima Sistemi")

    kullanici_katilim_sayilari = {}

    for aralik, katilimcilar in veri[tarih_str].items():
        katilim_listesi = ""
        for uid, bilgiler in katilimcilar.items():
            katilim_listesi += f"- {bilgiler['ad']} (ID: {uid}) - Katılım Saati: {bilgiler['katilim_zamani']}\n"
            kullanici_katilim_sayilari[uid] = kullanici_katilim_sayilari.get(
                uid, 0) + 1
        embed.add_field(name=f"🕒 Saat Aralığı: {aralik}",
                        value=katilim_listesi or "Kimse katılmadı.",
                        inline=False)

    toplam_katilim_str = ""
    for uid, toplam in kullanici_katilim_sayilari.items():
        # Burada isim alma denemesi
        isim = None
        for aralik_veri in veri[tarih_str].values():
            if uid in aralik_veri:
                isim = aralik_veri[uid]["ad"]
                break
        if isim is None:
            isim = "Bilinmiyor"
        toplam_katilim_str += f"- {isim} (ID: {uid}): {toplam} kere\n"

    embed.add_field(name="📈 Toplam Katılım Sayıları",
                    value=toplam_katilim_str or "Veri yok.",
                    inline=False)

    # Dilersen logo veya başka görsel linki ekleyebilirsin:
    embed.set_thumbnail(
        url=
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcyGaor8ZGFP_FdfX1rG1-JCOrTbE-SJOTOg&s"
    )

    await kanal.send(embed=embed)
    await ctx.send("📢 İçtima raporu log kanalına gönderildi.", ephemeral=True)


@bot.event
async def on_ready():
    print(f"{bot.user} olarak giriş yapıldı.")


keep_alive()
import os

print(os.getenv('REPLIT_URL'))

bot.run(TOKEN)
